# termux-ubuntu

cara install dan pasang Aplikasi termux di android 

dengan kode perintah seperti di bawah ini
 pkg update
pkg upgrade
pkg install git
pkg install wget
pkg install proot
 git clone https://github.com/kumpulanremaja/ubuntu
 cd ubuntu
chmod +x ubuntu.sh
./ubuntu.sh

kode untuk menjalankan ubuntu di termux 

 ./start-ubuntu.sh

untuk selengkapnya cek di https://www.kumpulanremaja.com/2019/08/cara-menggunakan-ubuntu-di-termux.html

